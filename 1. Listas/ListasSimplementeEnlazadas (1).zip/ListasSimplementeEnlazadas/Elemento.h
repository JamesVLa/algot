/* 
 * File:   Elemento.h
 * Author: ANA RONCAL
 *
 * Created on 11 de abril de 2025, 2:45 PM
 */

#ifndef ELEMENTO_H
#define ELEMENTO_H

/*información de la lista, acá se pueden añadir más datos*/
struct Elemento{
    int numero;  
};

#endif /* ELEMENTO_H */