/* 
 * File:   Pila.h
 * Author: ANA RONCAL
 *
 * Created on 20 de abril de 2025, 20:06
 */

#ifndef PILA_H
#define PILA_H
#include "Lista.h"
struct Pila{
    struct Lista lista;
};

#endif /* PILA_H */